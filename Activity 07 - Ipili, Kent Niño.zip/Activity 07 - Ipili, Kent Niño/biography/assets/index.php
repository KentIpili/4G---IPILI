<?php 

$info = array ("name" => "Kent Niño L. Ipili", "Age" => "20" ,  "Sex" => "Male" , "nationality" => "Filipino") ;


?>