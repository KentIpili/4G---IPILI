<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "libero";

$conn = new mysqli($host, $username, $password, $database);

if(isset($_POST['submit'])){

    if(!empty($_POST['postcode']) && !empty($_POST['email']) && !empty($_POST['number'])){

    $name = $_POST['postcode'];
    $email = $_POST['email'];
    $number = $_POST['number'];

  $query = "insert into forms (postcode, email, number)  values('$name','$email', '$number' )";

  $run = mysqli_query($conn , $query) or die(mysqli_error());

  if ($run){

    echo "Form Submitted Succesfully! Thank you!";
}
  
  else{
    echo "Form not Submitted";
     }
}
else{

    echo "All fields are Required!";
}
}

?>