<!DOCTYPE html>
<html>

<title>
   newlibero
</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="./css/newlibero.css"/>
<link rel="stylesheet" href="./css/media.css"/>
<link rel="stylesheet" href="./css/media2.css"/>
<link rel="stylesheet" href="./css/media3.css"/>

<!--FONT 1-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap" rel="stylesheet">
<!--FONT 2-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
<!--FONT 3-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans:wght@300&display=swap" rel="stylesheet">
<!--sarch-->


<header>
    <div class="navigationbar">

        <ul>

            <li>
            <div class="wrapper">

                <a href="#" class="nav">
                    <div class="one"></div>
                    <div class="two"></div>
                    <div class="three"></div>
                </a>
            </div>
        </li>
        <li>

                <a href="#"><img src="./image/libero.png" alt="Image not Available" class="liberoimg"></a>   
        
                <a class="highlight" href="NEWLIBERO.php" > <?php include 'arrays.php'; echo $nav['n1']; ?> </a>
                <a class="highlight" href="NEWLIBERO.php"> <?php include 'arrays.php'; echo $nav['n2']; ?></a>
                <a class="highlight" href="NEWLIBERO.php"> <?php include 'arrays.php'; echo $nav['n3']; ?> </a>
                <a class="highlight" href="NEWLIBERO.php"> <?php include 'arrays.php'; echo $nav['n4']; ?></a>

            </li>

           <li>
         <div class="container1">
            <i class="fas fa-search"></i>
         </div>
           </li>
        </ul>
    </div>
</header>