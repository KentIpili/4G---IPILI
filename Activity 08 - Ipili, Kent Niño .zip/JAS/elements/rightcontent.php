<!--RIGHT CONTENT-->

<div class="rightcontent">
    <div class="title1">Phasellus augue <br>   sapien     </div>
    
  
       <div class="border">
             <!--HOROZINTAL BAR-->
                  <a href="#" class="b1">
                    <div class="one"></div>
                 </a> 

       </div>       
    <!--RIGHT CONTENT IMAGE 1-->
       <div class="rcontentimg"> 
          <img height="130" width="200" src="./image/1b.jpeg" alt="Image not Available">
            <div class="overlay">
                <div class="text">Vestibulum sit amet <br>
                    tempor orci</div>
                    <p class="text2"> Read More  >></p>
            </div>     
        </div>   
         <div class="content1">
              <p> Phasellus augue sapien,<br>
              aliquam sit amet mauris</p>

         </div>

            <!--HOROZINTAL BAR-->
     <div class="border2">
            <a href="#" class="b1">
            <div class="one"></div>
           </a> 

    </div>

             <!--RIGHT CONTENT IMAGE 2-->
    <div class="rcontentimg2"> 
          <img height="130" width="200" src="./image/1c.jpeg" alt="Image not Available">
         <div class="overlay2">
             <div class="text3">Integer consectetur <br>
                     orci ligula</div>
                     <p class="text4"> Read More  >></p>
             </div>     
     </div>          

        <div class="content2">
             <p> Sed facilisis volutpat   <br>
             turpis eu viverra
            </p>

         </div>

</div>