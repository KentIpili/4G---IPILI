<div class="footer">
        
  <div class="columns">

            <div class="column1">
                     <div class="bcontent"> Rutrum </div>  
                     <div class="horizontal1"></div>
                 <ul > 

                <li>Fermentum</li>
                <li>Neque</li>
                <li>Consequat</li>

                 </ul>
             </div>




        <div class="column2">
             <div class="bcontent"> Malesuada</div>
             <div class="horizontal1"></div>

              <ul > 

                 <li>Tellus</li>
                 <li>Condimentum</li>
                 <li>Consectetur</li>


             </ul>
        </div>

   

        <div class="column3">
             <div class="bcontent"> Pellentesque</div> 
                     <div class="horizontal1"></div>
                <ul > 

                     <li>Habitant</li>
                    <li>Morbi </li>
                     <li>Tristique</li>

                 </ul>

        </div>

        <div class="column4">
                     <div class="bcontent"> Quisque</div> 
                     <div class="horizontal1"></div>
                <ul > 

                <li>Pharetra </li>
                 <li>Volutpat</li>
                <li>Tristique</li>



                 </ul>
        </div>   




    <div class="footer1">
        <div class="c5">
    
            <div class="circle1"> </div>
            <div class="name"> Phasellus </div>
        </div>  
        <div class="c6">
            <div class="circle1"> </div>
            <div class="name"> Augue</div>
        </div>
        <div class="c7">
            <div class="circle1"> </div>
            <div class="name">Sapien</div>
        </div>
    
    </div>
  </div>
</div>
 
</html> 