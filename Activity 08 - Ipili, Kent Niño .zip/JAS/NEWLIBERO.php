
<?php include 'elements/header.php';
    
       
?>

<?php include 'elements/rightcontent.php';
?>


    
<body> 
                    <!--VERTICAL LINE-->
<div class="verticalline">
            
<form action="forms.php"  method="POST">   


                                     <div class="question1">
                                      How do you feel about recycling?
                                     </div>
            <div class="questions">
                     <div class="postbox">
               
                                <p>Postcode:</p>
                              <input type="number" placeholder="" name="postcode">

                      </div>
          
             

                    <div class="question2">

                         <p>
                             Should the government start enforcing garbage
                            </p>
                                <p>
                                     separation and recycling schemes across your area?
                                    </p>
                   
                    </div>
  

                <!--YES OR NO BUTTON-->

            <div class="yesorno">
             <ul>
    
                <li>
                     <div class="yesbtn">
                            <label class="container">
                                 <input type="radio" checked="checked" name="radio">
                                <span class="checkmark"></span> Yes
                                </label>

                    </div>
                </li>
              
                <li>
                    <div class="nobtn">
                             <label class="container">
                                <input type="radio" checked="checked" name="radio">
                                <span class="checkmark"></span> No
                            </label>
                    </div>
               </li>
  
           </ul>   
     
    </div>   

                  
          <br>
               
    
                    <!--EMAIL ADDRESS AND MOBILE NUMBER -->
    
        <div class="boxes">
                    
                    <p>E-mail Address: </p>
                     <input type="email" placeholder=""  name="email">
<br>
                    <p>Mobile Number:</p>       
                    <input type="number" placeholder="" name="number">
<div class="break1"></div>
                     <input class="form-submit-button" type="submit"  name="submit" >
                     
                
                    </div>
        </div>
</div>
</div> 
</form> 
</body>


<div class="break"> </div>

<?php include 'elements/footer.php'; ?>