
<?php 

$nav = array ("n1" => "HOME", "n2" => "NEWS", "n3" => "EVENTS", "n4" => "WORLD")

?>