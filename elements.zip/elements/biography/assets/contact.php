<?php
 include 'header.php';
?>
                    
               <div class="Cntct">
     <ul>
     <li> <img  height="25" width="25" src="insta.png" alt="Image not available"></li>
     <li><p>imnotkeeent</p></li>
     </ul>  

          <ul>
          <li>   <img  height="30" width="50" src="fb.png" alt="Image not available"></li>
          
     <li><p> Kent Niño L. Ipili </p> </li>
     </ul>
     <ul>
     <li><img  height="25" width="25" src="gmail.png" alt="Image not available"></li>
          <li> 
       <p> kentipili20@gmail.com</p></li>
          </ul>
                        
                </div>    
                                                

                </div>                  
                
</html>