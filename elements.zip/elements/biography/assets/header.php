
<!DOCTYPE html>
<html>
  <link rel="stylesheet" href="media1.css"/>
  <link rel="stylesheet" href="media2.css"/>
  <meta charset="UTF-8">
 
<title>
    Contact
</title>

<header>

</header>

<div class= "title">
           <h1>  Kent  Biography </h1> 
              
</div>    
<div class="line1"> 
  <div class="Navbar">    
   
            
              <a class="highlight" href="project1.php">About Me</a>
              <a class="highlight"  href="contact.php">Social Media </a>
        
     </div>   
                     


</div>