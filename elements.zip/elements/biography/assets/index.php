<?php 

$info = array ("name" => "Kent Niño L. Ipili", "Age" => "20" ,  "Sex" => "Male" , "dob" => "December 17,2001", "nationality" => "Filipino") ;


?>