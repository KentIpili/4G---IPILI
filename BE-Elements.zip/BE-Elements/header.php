<?php 

 ?>        
          <!three bar menu>
          <header> 
              <div class="menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
  
              <div class="menu-content">
              <a href="#">HOME</a>
              <a href="#">NEWS</a>
              <a href="#">EVENTS</a>
              <a href="#">WORLD</a>
              </div>
              </div>
          
              <!libero logo>
              <div class="logo">
              <a href="#"><img src="assets\images\libero.png"></a>
            </div>
        
            <!Navigation Bar>
            <nav>   
                <a href="#" >HOME</a></li>
                <a href="#" >NEWS</a></li>
                <a href="#" >EVENTS</a></li>
                <a href="#" >WORLD</a></li>
              </nav>
                  <!–– Search Icon ––>
                  <div class="SearchBox">
                  <div id="magnifying-glass">
                  <input id="field" type="text" value="Search here"/>    
                  </div>   
                  </div>
              
            
          </header>