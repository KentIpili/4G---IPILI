<div class="Name">
              
               <div class="bio">   <div class="text"> <p>
       <p></p> My name is Kent Niño L. Ipili and I was born on the 17th of December,2001 in Toledo City, Cebu. 
	       My parents names are Pedro Ipili and Jeanie Ipili. We are five (5) siblings in the family, 4 boys and 1 girl.
	       
	      <p></p>There are a lot of things I like. I like to have fun with my friends, I love playing basketball, and listening music. My hobbies are running, walking, watching movies, and reading books. I also spend my free time into the gym with my friends. My dreams was to become a Computer Engineering.
	       I am very introverted. I am somewhat quiet and I am very reserved with my personal life. I am quick to react emotionally to situations that make me happy or upset. The one thing I lack is openness to experience. I have done better, but I still tend to stick to my comfort zone. Although I lack openness, I have a very high level of conscientiousness. I am very organized. I also am very dependable. All in all, I am a very kind, helpful, and patient person so I am very high in agreeableness. These characteristics help me to say that I have a good amount of emotional.
	     
	       <p></p> School is very important to me because without school it would be hard to make a living. I also like school because it gives me a challenge to better myself and my grades. School affects your whole life because if you don’t get good grades you might now be able to get a good job your whole life. Even though it isn’t my favorite thing to do, I’ll probably look back and think thank God I went to school.
	       I’m sometimes content with myself if I try my hardest. If I don’t try my hardest, I wish that I would have been better so I wouldn’t be upset with myself. I feel like if you don’t try your hardest you shouldn’t be able to succeed and achieve your goals.
	      
	       <p></p> Goals in life are to study hard, be my dream job and give my family a better life.
	       I also have a life verse and I would like to share it "Commit to the LORD whatever you do, and he will establish your plans." 
	       I always relay my life to this verse, this means When we "commit" our works to the Lord, we are offering everything we do completely to Him. If we completely depend on God in our work, He will “establish” our plans. He will “bring about/cause to happen” our plans.
	       Fight, even if a lot of works to do I will accomplish it and even there is the time you wanted to give up just talk to go, "you can do it".<br>
               
         

                </div>
                <br class="lines"> 
                

              

      

</html>