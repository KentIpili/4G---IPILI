<?php
include 'header.php';
?>
     


               <div class="contact">
               
                <div class="contact1"> Direct Me!</div>
                    
                <div class="Cntct">

                      
                      <ul>
                        <li> <img  height="25" width="25" src="./assets/insta.png" alt="Image not available"></li>
                        <li><p>imnotkeent</p></li>
                      </ul>  

                      <ul>
                        <li>   <img  height="30" width="50" src="./assets/fb.png" alt="Image not available"></li>
                      <li>    <p> Kent Niño Ipili</p> </li>
                  </ul>

                       <ul>
                        <li><img  height="25" width="25" src="./assets/gmail.png" alt="Image not available"></li>
                       <li> <p> kentipili20@gmail.com</p></li>
                       </ul>
                        
                   </div>    
                   
                                 



                </div>
                    



</html>