<?php 

&copy;
echo date('m/d/Y');
exit();

?>