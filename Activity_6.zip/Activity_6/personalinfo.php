<div class="profile"> PROFILE </div>

         
<div class="pic">
                <img width="300"  height="300" src="./assets/profile.jpg" alt="Image not available">
                
             </div> 
   <?php do{ ?>           

             <div class="personalinfo">
          
      

              <div class="Pname">  <span>   Name :</span> <?php  echo $row['Name']; ?> </div>
              <div class="Pname">  <span>    Age : </span> <?php  echo $row['Age']; ?></div>
              <div class="Pname">  <span>   Date of Birth :</span> <?php  echo $row['Birthdate']; ?></div>
              <div class="Pname">  <span>   Nationality:</span> <?php  echo $row['Nationality']; ?></div>
    
              </div>  



           <?php }while($row = $data->fetch_assoc());