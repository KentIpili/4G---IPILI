<?php

$host = "localhost";
$username = "root";
$password = "12345";
$database = "biography";

$con = new mysqli($host, $username, $password, $database);

if($con->connect_error){
            echo $con->connect_error;
}

$sql = "SELECT * FROM info1";
$data = $con->query($sql) or die ($con->error);

$row = $data->fetch_assoc();

print_r($row);

do{

echo $row ['Name']."</br>";
echo $row ['Age']."</br>";
echo $row ['Birthdate']."</br>";
echo $row ['Nationality']."</br>";


}while($row = $data->fetch_assoc());
?>