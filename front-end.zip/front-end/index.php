<?php 


 ?>


<!DOCTYPE html>
  <html> 
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <link rel="stylesheet" type="text/css" href="assets\css\css.css">
    </head>

        <body>
      
          <header>
            <div class="menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
  
            <div class="menu-content">
              <a href="#">HOME</a>
              <a href="#">NEWS</a>
              <a href="#">EVENTS</a>
              <a href="#">WORLD</a>
              </div>
            </div>
          
            <div class="logo">
              <a href="#"><img src="assets\images\libero.png"></a>
            </div>
        
  
              <nav>   
                <a href="#" >HOME</a></li>
                <a href="#" >NEWS</a></li>
                <a href="#" >EVENTS</a></li>
                <a href="#" >WORLD</a></li>
              </nav>
                <!–– Search Icon ––>
                  <div class="SearchBox">
                    <div id="magnifying-glass">
                      <input id="field" type="text" value="Search here"/>    
                    </div>   
                  </div>
                  
          </header>

          <main>
            <div class="survey">
              <h1>How do you feel about recycling?</h1>
              <label class="postal">Postcode: <br>
              <input type="code" id="postcode" required>
              </label>
              <label class="postal">Should the government start enforcing garbage <br>
              separation and recycling schemes across your area?</label>
       
              <div class="selection">           
                <input type="radio" name="select" id="yes" required>
                <input type="radio" name="select" id="no" required>

                  <label for ="yes" class="yes">
                    <div class="dot"></div>
                    <div class="text">Yes</div>
                  </label>
                  <label for ="no" class="no">
                    <div class="dot"></div>
                    <div class="text">No</div>
                  </label>
              </div>
            </div>
        
            <form>
              <label>E-mail Address:<br>
              <input type="text" name="email" required> 
              </label><br>
              <label>Mobile Number:<br>
              <input type="number" name="mobile" required>
              </label>
              <div class="submit">
                <button class="button">Submit</button> 
              </div>
            </form>
          </main>
      
          <aside>
            <section class="ads">
              <h2>Phasellus augue<br> sapien</h2>
                
                  <section class="adscontainer1">
                    <a href="#"><img src="assets\images\1b.jpeg">
                    <div class="centertext1">Vestibulum sit amet<br> tempor orci</div><br>
                    <button class="button1">Read more >></button></a>
                    <div class="bottomtext1">Phasellus augue sapien,<br> aliquam sit amet mauris</div>
                  </section>
                  <section class="adscontainer2">
                    <a href="#"><img src="assets\images\1c.jpeg">
                      <div class="centertext2">Integer consectetur<br> orci ligula</div><br>
                      <button class="button2">Read more >></button></a>
                      <div class="bottomtext2">Sed facilisis volutpat<br> turpis eu viverra</div>
                  </section>
   
            </section>
          </aside>

          <footer class="footer">
            <div class="container">
                <div class="footer-col">
                  <h4>Rutrum</h4>
                    <ul>
                      <li><a href="#">Fermentum</a></li>
                      <li><a href="#">Neque</a></li>
                      <li><a href="#">Consequat</a></li>
                    </ul>
                </div>
            <div class="footer-col">
              <h4>Malesuada</h4>
                <ul>
                  <li><a href="#">Tellus</a></li>
                  <li><a href="#">Condimentum</a></li>
                  <li><a href="#">Consectetur</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <h4>Pellentesque</h4>
                <ul>
                  <li><a href="#">Habitant</a></li>
                  <li><a href="#">Morbi</a></li>
                  <li><a href="#">Tristique</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <h4>Quisque</h4>
                <ul>
                  <li><a href="#">Pharetra</a></li>
                  <li><a href="#">Volutpat</a></li>
                  <li><a href="#">Tristique</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <div class="circles">
                <ul>
                  <li><button class="circlebutton"></button><a href="#">Phasellus</a></li>
                  <li><button class="circlebutton"></button><a href="#">Augue</a></li>
                  <li><button class="circlebutton"></button><a href="#">Sapien</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>

      </body>
</html>